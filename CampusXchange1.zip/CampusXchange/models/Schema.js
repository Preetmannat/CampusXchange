const mongoose = require("mongoose");

const Schema = new mongoose.Schema({
    title:{
        type:String,
        requires:true,
    },
    description:String,
    image:{
        type:String,
        default:"https://unsplash.com/photos/a-single-leaf-on-a-twig-in-a-forest-913aM5bLFIg",
        set:(v) => v === ""?"https://unsplash.com/photos/a-single-leaf-on-a-twig-in-a-forest-913aM5bLFIg":v,
    
    },
    price:Number,
    location:String
});
const Item = mongoose.model("Item",Schema);
module.exports = Item;